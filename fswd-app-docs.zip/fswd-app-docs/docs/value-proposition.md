---
title: Value Proposition
nav_order: 1
---

{: .label }
[Jane Dane]

{: .no_toc }
# Value proposition

<details open markdown="block">
{: .text-delta }
<summary>Table of contents</summary>
+ ToC
{: toc }
</details>

## The problem

[Describe which problem your application tackles and why it is relevant.]

## Our solution

[Describe why and how your app solves the stated problem. Don't over-promise: the description should match what your app actually delivers.]

## Target user

[Scope your target user(s), e.g., with the help of personas.]

## Customer journey

[Illustrate the customer journey, from the app's entry point to a completed task. You might want to show the customer journey as (schematic) screen flows.]