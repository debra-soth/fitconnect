---
title: Improvements
parent: Team Evaluation
nav_order: 2
---

{: .label }
[Jane Dane]

{: .no_toc }
# How we would improve next time

<details open markdown="block">
{: .text-delta }
<summary>Table of contents</summary>
+ ToC
{: toc }
</details>
